package bomberman;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JPanel;


public class Figur extends JPanel{
    private Image[] Sprites=new Image[4];
    GUIComponent component = new GUIComponent(0,0,0,0);
    private int keyStroke=1;
    private int x = 76,y = 16;
    
    public Figur() {
        this.setPreferredSize(new Dimension(component.getWidth(), component.getHeight()));       
    }
    
    public Figur(int type){
        this();
        //1=unten,2=links,3=rechts,4=oben
        switch(type){
            case 1:{
            try {
                Sprites[0]=ImageIO.read(Figur.class.getResource("sprites/trump/1.png"));
                Sprites[1]=ImageIO.read(Figur.class.getResource("sprites/trump/2.png"));
                Sprites[2]=ImageIO.read(Figur.class.getResource("sprites/trump/3.png"));
                Sprites[3]=ImageIO.read(Figur.class.getResource("sprites/trump/4.png"));
            } catch (IOException ex) {
                Logger.getLogger(Figur.class.getName()).log(Level.SEVERE, null, ex);
            }
            break;
            }
            case 2:{
            try {
                Sprites[0]=ImageIO.read(Figur.class.getResource("sprites/fatKorean/1.png"));
                Sprites[1]=ImageIO.read(Figur.class.getResource("sprites/fatKorean/2.png"));
                Sprites[2]=ImageIO.read(Figur.class.getResource("sprites/fatKorean/3.png"));
                Sprites[3]=ImageIO.read(Figur.class.getResource("sprites/fatKorean/4.png"));
            } catch (IOException ex) {
                Logger.getLogger(Figur.class.getName()).log(Level.SEVERE, null, ex);
            }
            break;
            }
        }
    }
    
    public void setKeyStroke(int keyStroke){
        this.keyStroke=keyStroke;
    }
    
    public GUIComponent getv(){
        return component;
    }
    
    public void setx(int x){
        this.x=x;
    }
    
    public void sety(int y){
        this.y=y;
    }
    
    public int getx(){
        return x;
    }
    
    public int gety(){
        return y;
    }
    
    public void paintComponent(Graphics g){
        switch(keyStroke){
            case 1:{
                g.drawImage(Sprites[0], x, y, null);
                break;
            }
            case 2:{
                g.drawImage(Sprites[1], x, y, null);
                break;
            }
            case 3:{
                g.drawImage(Sprites[2], x, y, null);
                break;
            }
            case 4:{
                g.drawImage(Sprites[3], x, y, null);
                break;
            }
        }
        
        
    }   
}
