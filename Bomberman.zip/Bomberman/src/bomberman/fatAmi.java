/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bomberman;

import java.awt.Image;

/**
 *
 * @author heindani
 */
public class fatAmi extends GUIComponent {

    public fatAmi(int width, int heigth, Image img, int x, int y) {
        super(width, heigth, img, x, y);
    }
    
    public void sprengen(){
        
    }
    
}
