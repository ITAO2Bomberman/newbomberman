/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bomberman;

import com.sun.javafx.image.PixelSetter;
import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 *
 * @author heindani
 */
public class BombermanPanel extends Container {

    private static final long serialVersionUID = 4161752677750100437L;

    private static final ArrayList<activity> ACTIVITIES = new ArrayList<>();

    private Bomberman bomberman;
    private int[][] walls;
    public BombermanPanel(Bomberman bomberman) {
        this.bomberman = bomberman;
//        Figur f1 = new Figur(1);
//        this.add(f1);
//        f1.setVisible(true);
//        this.addKeyListener(new KeyListener() {
//
//            @Override
//            public void keyTyped(KeyEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//            }
//
//            @Override
//            public void keyPressed(KeyEvent e) {
//                if (e.getKeyCode() == KeyEvent.VK_UP) {
//                    f1.setKeyStroke(4);
//                    if (!Kollision.Kollisionsberechnung(f1.getx(), f1.gety()- 16,bomberman))  {
//
//                        f1.sety(f1.gety() - 16);
//                    }
//                }
//                if (e.getKeyCode() == KeyEvent.VK_DOWN) {
//                    f1.setKeyStroke(1);
//                    if (!Kollision.Kollisionsberechnung(f1.getx(), f1.gety() + 16, bomberman)) {
//
//                        f1.sety(f1.gety() + 16);
//
//                    }
//                }
//
//                if (e.getKeyCode() == KeyEvent.VK_LEFT) {
//                    f1.setKeyStroke(2);
//                    if (!Kollision.Kollisionsberechnung(f1.getx() - 16, f1.gety(), bomberman)) {
//                        f1.setx(f1.getx() - 16);
//                    }
//                }
//                if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
//                    f1.setKeyStroke(3);
//                    if (!Kollision.Kollisionsberechnung(f1.getx() + 16, f1.gety(), bomberman)) {
//                        f1.setx(f1.getx() + 16);
//                    }
//                }
//                repaint();
//            }
//
//            @Override
//            public void keyReleased(KeyEvent e) {
//                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//            }
//        });
    }

    public void paint(Graphics g) {
        super.paint(g);
        for (int i = 60; i < bomberman.getWidth() - 16; i += 16) {
            for (int j = 0; j < bomberman.getHeight() - 32; j += 16) {
                if (i == 60 || j == 0 || j >= bomberman.getHeight() - 48 || i >= bomberman.getWidth() - 32) {
                    GUIComponent gui = new GUIComponent(16, 16, new ImageIcon(BombermanPanel.class.getResource("sprites/mauer/mauergeil.png")).getImage(), i, j);
                    gui.render((Graphics2D) g);
                }
            }
        }
        for (int k = 0; k < 11; k++) {
            for (int l = 0; l <= 6; l++) {
                GUIComponent gui = new GUIComponent(16, 16, new ImageIcon(BombermanPanel.class.getResource("sprites/mauer/pixelmauermitte.png")).getImage(), 96 + 32 * k, 32 + 32 * l);
                gui.render((Graphics2D) g);
            }
        }
        bomberman.getThread().nowait();
    }

}
