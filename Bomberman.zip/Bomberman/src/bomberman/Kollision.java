/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bomberman;

import bomberman.GUIComponent;
import java.util.ArrayList;

/**
 *
 * @author MichaL
 */
public class Kollision {

    public static boolean Kollisionsberechnung(int x, int y, Bomberman bomberman) {
        int[][] eisberg = waende(bomberman);
        for (int i = 0; i < eisberg.length; i++) {
            if (eisberg[i][0] == x && eisberg[i][1] == y || x < 0 || y < 0 || x > 480 - 16 || y > 272 - 16) {
                System.out.println("Kollision");
                return true;

            } else {

            }
        }
        return false;
    }

    private static int[][] waende(Bomberman bomberman) {
        ArrayList<int[]> ret = new ArrayList<>();
        for (int i = 60; i < bomberman.getWidth() - 16; i += 16) {
            for (int j = 0; j < bomberman.getHeight() - 32; j += 16) {
                if (i == 60 || j == 0 || j >= bomberman.getHeight() - 48 || i >= bomberman.getWidth() - 32) {
                    int[] l = {i, j};
                    ret.add(l);
                }
            }
        }
        for (int k = 0; k < 11; k++) {
            for (int l = 0; l <= 6; l++) {
                int[] u = {k, l};
                ret.add(u);
            }
        }
        int[][] re = new int[ret.size()][2];
        for (int i = 0; i < ret.size(); i++) {
            re[i][0] = ret.get(i)[0];
            re[i][1] = ret.get(i)[1];
        }
        return re;
    }
}
